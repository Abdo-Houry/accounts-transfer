import path from 'path';
import dotenv from 'dotenv';
import { z } from 'zod';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

/**
 * Boolean from an environment string.
 *
 * `z.coerce.boolean()` is NOT usable here: it applies `Boolean("false")`, which
 * is `true`. Every flag in this file would then be permanently on - including
 * `DB_SYNCHRONIZE`, which would let TypeORM rewrite a production schema.
 */
const envBoolean = (defaultValue: boolean) =>
  z
    .string()
    .optional()
    .transform((value) => {
      if (value === undefined || value.trim() === '') return defaultValue;
      return ['1', 'true', 'yes', 'on'].includes(value.trim().toLowerCase());
    });

/**
 * Fail fast on a bad environment. A financial service must never boot with a
 * default JWT secret or a half-configured database.
 */
const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(4000),
  API_PREFIX: z.string().startsWith('/').default('/api/v1'),
  CORS_ORIGINS: z.string().default('http://localhost:5173,http://127.0.0.1:5173'),

  DB_HOST: z.string().min(1),
  DB_PORT: z.coerce.number().int().positive().default(5432),
  DB_USERNAME: z.string().min(1),
  DB_PASSWORD: z.string(),
  DB_DATABASE: z.string().min(1),
  DB_SCHEMA: z.string().default('public'),
  DB_SSL: envBoolean(false),
  DB_LOGGING: envBoolean(false),
  DB_SYNCHRONIZE: envBoolean(false),

  JWT_ACCESS_SECRET: z.string().min(32, 'JWT_ACCESS_SECRET must be at least 32 characters'),
  JWT_REFRESH_SECRET: z.string().min(32, 'JWT_REFRESH_SECRET must be at least 32 characters'),
  JWT_ACCESS_EXPIRES_IN: z.string().default('15m'),
  JWT_REFRESH_EXPIRES_IN: z.string().default('7d'),
  BCRYPT_ROUNDS: z.coerce.number().int().min(10).max(15).default(12),
  COOKIE_SECURE: envBoolean(false),
  COOKIE_DOMAIN: z.string().optional(),

  DEFAULT_LANGUAGE: z.enum(['ar', 'en', 'tr']).default('ar'),
  BASE_CURRENCY: z.string().length(3).default('SYP'),

  LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).optional(),

  SEED_ADMIN_USERNAME: z.string().default('admin'),
  SEED_ADMIN_PASSWORD: z.string().default('Admin@12345'),
  SEED_ADMIN_FULLNAME: z.string().default('System Administrator'),
});

const parsed = schema.safeParse(process.env);

if (!parsed.success) {
  const issues = parsed.error.issues
    .map((issue) => `  - ${issue.path.join('.')}: ${issue.message}`)
    .join('\n');
  // Thrown before the logger exists, so a plain message is the clearest signal.
  throw new Error(`Invalid environment configuration:\n${issues}`);
}

const raw = parsed.data;

export const env = {
  ...raw,
  isProduction: raw.NODE_ENV === 'production',
  isDevelopment: raw.NODE_ENV === 'development',
  isTest: raw.NODE_ENV === 'test',
  corsOrigins: raw.CORS_ORIGINS.split(',')
    .map((origin) => origin.trim())
    .filter(Boolean),
} as const;

if (env.isProduction && env.DB_SYNCHRONIZE) {
  throw new Error('DB_SYNCHRONIZE must be false in production - use migrations.');
}

export type Env = typeof env;
