import 'reflect-metadata';
import { createApp } from './app';
import { env } from './config/env';
import { AppDataSource, initializeDataSource } from './config/data-source';
import { logger } from './utils/logger';
import { findMissingKeys } from './utils/i18n';

async function bootstrap(): Promise<void> {
  await initializeDataSource();
  logger.info('Database connected', { database: env.DB_DATABASE, host: env.DB_HOST });

  // Surface an incomplete translation catalogue at boot rather than in front of
  // an operator who suddenly sees an English string in an Arabic screen.
  const missing = findMissingKeys();
  if (Object.keys(missing).length > 0) {
    logger.warn('Missing translation keys', missing);
  }

  const app = createApp();
  const server = app.listen(env.PORT, () => {
    logger.info('API listening', {
      port: env.PORT,
      prefix: env.API_PREFIX,
      environment: env.NODE_ENV,
    });
  });

  /**
   * Graceful shutdown matters here: a request that is halfway through a money
   * transaction must be allowed to commit or roll back cleanly before the
   * process exits.
   */
  const shutdown = async (signal: string): Promise<void> => {
    logger.info(`Received ${signal}, shutting down`);
    server.close(async () => {
      try {
        if (AppDataSource.isInitialized) await AppDataSource.destroy();
        logger.info('Shutdown complete');
        process.exit(0);
      } catch (error) {
        logger.error('Error during shutdown', { error });
        process.exit(1);
      }
    });

    // Do not hang forever if a socket refuses to close.
    setTimeout(() => process.exit(1), 15_000).unref();
  };

  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));

  process.on('unhandledRejection', (reason) => {
    logger.error('Unhandled promise rejection', { reason });
  });
  process.on('uncaughtException', (error) => {
    logger.error('Uncaught exception - exiting', { error });
    process.exit(1);
  });
}

bootstrap().catch((error) => {
  logger.error('Failed to start the server', { error });
  process.exit(1);
});
