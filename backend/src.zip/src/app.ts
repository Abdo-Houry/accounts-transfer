import 'reflect-metadata';
import express, { type Express } from 'express';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { env } from './config/env';
import routes from './routes';
import { errorHandler, notFoundHandler, requestContext } from './middleware';
import { logger } from './utils/logger';

export function createApp(): Express {
  const app = express();

  // Behind nginx / a load balancer, one hop is trusted so `req.ip` and the
  // secure-cookie logic see the real client rather than the proxy.
  app.set('trust proxy', 1);
  app.disable('x-powered-by');

  app.use(helmet({ crossOriginResourcePolicy: { policy: 'same-site' } }));

  app.use(
    cors({
      origin(origin, callback) {
        // Same-origin and server-to-server calls arrive without an Origin header.
        if (!origin || env.corsOrigins.includes(origin)) return callback(null, true);

        // Deny by omitting the CORS headers rather than by throwing: the browser
        // is what must block the response, and throwing here would turn a policy
        // decision into a 500 that looks like a server fault to the operator.
        logger.warn('Blocked a cross-origin request', { origin });
        callback(null, false);
      },
      credentials: true,
      exposedHeaders: ['x-request-id', 'content-language'],
    }),
  );

  app.use(compression());
  app.use(cookieParser());
  // A 200 kB ceiling is generous for JSON operations and keeps a runaway payload
  // from occupying a worker.
  app.use(express.json({ limit: '200kb' }));
  app.use(express.urlencoded({ extended: true, limit: '200kb' }));

  app.use(requestContext);

  if (!env.isTest) {
    app.use(
      morgan(env.isProduction ? 'combined' : 'dev', {
        stream: { write: (line) => logger.info(line.trim(), { channel: 'http' }) },
        skip: (req) => req.path === `${env.API_PREFIX}/health`,
      }),
    );
  }

  app.use(env.API_PREFIX, routes);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
